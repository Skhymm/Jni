#include "netgame.h"
#include "xorstr.h"
#include "plugin.h"
#include <ctime>

#define NETGAME_VERSION 4057
extern JavaVM* g_jvm;
extern jclass g_jsonTransportClass;
extern jmethodID g_onJsonDataMethod;

extern RakClientInterface* pRakClient;

uint16_t CNetGame::m_nLastSAMPDialogID;
static bool g_PendingAwaitJoin = false;
static uint64_t g_ConnectionLostAtMs = 0;

static uint64_t GetTickCountMS()
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return static_cast<uint64_t>(ts.tv_sec) * 1000ULL + static_cast<uint64_t>(ts.tv_nsec) / 1000000ULL;
}

static uint16_t PackSampHealthArmourForBR(uint8_t value)
{
	if (value > 100) {
		value = 100;
	}
	return static_cast<uint16_t>(value) << 8;
}

static bool ReadPacketPlayerHeader(Packet* pkt, RakNet::BitStream& bsData, uint8_t expectedPacketId, uint16_t& playerId)
{
	if(!pkt || !pkt->data) {
		return false;
	}

	uint8_t packetId = 0;
	if ((uint8_t)pkt->data[0] == ID_TIMESTAMP) {
		const size_t minLength = sizeof(uint8_t) + sizeof(RakNetTime) + sizeof(uint8_t) + sizeof(uint16_t);
		if (pkt->length < minLength) {
			return false;
		}
		bsData.IgnoreBits(8);
		bsData.IgnoreBits(static_cast<int>(sizeof(RakNetTime) * 8));
	}
	if(!bsData.ReadBits((unsigned char *)&packetId, 8)) {
		return false;
	}
	if(packetId != expectedPacketId) {
		return false;
	}
	if(!bsData.ReadBits((unsigned char *)&playerId, 16)) {
		return false;
	}
	return true;
}

uint8_t GetPacketID(Packet *p)
{
	if(p == 0) { return 255; }
	if ((uint8_t)p->data[0] == ID_TIMESTAMP) {
		size_t offset = sizeof(uint8_t) + sizeof(RakNetTime);
		if (p->length <= offset) {
			return 255;
		}
		return (uint8_t)p->data[offset];
	} else {
		return (uint8_t)p->data[0];
	}
}

void CallOnJsonDataIncoming(int guiId, const char* jsonData) {
    if (!g_jvm || !g_jsonTransportClass || !g_onJsonDataMethod) {
//        CChat::AddDebugMessage(xorstr("JNI not initialized"));
        return;
    }
    
    JNIEnv* env;
    int status = g_jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
    
    if (status == JNI_EDETACHED) {
        if (g_jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
        //    CChat::AddDebugMessage(xorstr("Failed to attach thread"));
            return;
        }
    } else if (status != JNI_OK) {
     //   CChat::AddDebugMessage(xorstr("Failed to get JNIEnv"));
        return;
    }
    
    jsize dataLength = strlen(jsonData);
    jbyteArray jData = env->NewByteArray(dataLength);
    env->SetByteArrayRegion(jData, 0, dataLength, (jbyte*)jsonData);
    
    env->CallStaticVoidMethod(g_jsonTransportClass, g_onJsonDataMethod, guiId, jData);
    
    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        env->ExceptionClear();
    }
    
    env->DeleteLocalRef(jData);
    
    if (status == JNI_EDETACHED) {
        g_jvm->DetachCurrentThread();
    }
}

CPlayerPool* CNetGame::GetPlayerPool()
{
    uintptr_t addr = CGameAPI::GetBase(xorstr("CNetGame::m_pPlayerPool"));
    if (!addr) return nullptr;
    return *(CPlayerPool **)(addr);
}

void CNetGame::ProcessNetwork()
{
	if (g_PendingAwaitJoin) {
		const uint64_t now = GetTickCountMS();
		if (now - g_ConnectionLostAtMs >= 15000ULL) {
			SetGameState(GAMESTATE_WAIT_CONNECT);
			g_PendingAwaitJoin = false;
		}
	}

	Packet* pkt = nullptr;
	uint8_t packetIdentifier;
	while(pkt = pRakClient->Receive())
	{
		packetIdentifier = GetPacketID(pkt);
		switch(packetIdentifier)
		{
			case ID_FAILED_INITIALIZE_ENCRIPTION:
				CChat::AddDebugMessage(xorstr("Failed to initialize encryption."));
				break;
			case ID_CONNECTION_ATTEMPT_FAILED:
				CChat::AddDebugMessage(xorstr("Отсутствует соединение. Для решения: попробуйте переподключить роутер, либо сменить интернет, либо воспользоваться VPN."));
				SetGameState(GAMESTATE_WAIT_CONNECT);
				
				break;
			case ID_NO_FREE_INCOMING_CONNECTIONS:
				CChat::AddDebugMessage(xorstr("Сервер полон. Переподключение..."));
				SetGameState(GAMESTATE_WAIT_CONNECT);
				pRakClient->Disconnect(0, 0);
				break;
			case ID_CONNECTION_BANNED:
				CChat::AddDebugMessage(xorstr("Вы были заблокированы на этом сервере."));
				break;
			case ID_INVALID_PASSWORD:
				CChat::AddDebugMessage(xorstr("Wrong server password."));
				pRakClient->Disconnect(0);
				break;
			case ID_AUTH_KEY:
				if (GetGameState() == GAMESTATE_CONNECTED) {
					Packet_TurnLightsSync(pkt);
				} else {
					Packet_AuthKey(pkt);
				}
				break;
			case ID_CONNECTION_REQUEST_ACCEPTED:
				CChat::AddDebugMessage(xorstr("Сделано дерикстоном зимой 26 года"));
				Packet_ConnectionSucceeded(pkt);
				break;
			case ID_CONNECTION_LOST:
				CChat::AddDebugMessage(xorstr("Переподключение через 15 секунд..."));

				g_ConnectionLostAtMs = GetTickCountMS();
				g_PendingAwaitJoin = true;
    			break;
			case ID_DISCONNECTION_NOTIFICATION:
				CChat::AddDebugMessage(xorstr("Сервер оборвал соединение."));
				CChat::AddDebugMessage(xorstr("Вы были отключены от сервера."));
				pRakClient->Disconnect(2000, 0);
				break;
			case ID_AIM_SYNC:
				Packet_AimSync(pkt);
				break;
				
			case ID_PLAYER_SYNC:
				Packet_PlayerSync(pkt);
				break;

			case ID_VEHICLE_SYNC:
				Packet_VehicleSync(pkt);
				break;

			case ID_PASSENGER_SYNC:
				Packet_PassengerSync(pkt);
				break;
			
			case ID_BULLET_SYNC:
				Packet_BulletSync(pkt);
				break;
			case 252:
            {
                RakNet::BitStream bsData(pkt->data, pkt->length, false);
                uint8_t packetId;
                uint16_t guiId;
                uint32_t jsonLength;
                
                bsData.Read(packetId);
                bsData.Read(guiId);
                bsData.Read(jsonLength);
                
                if(guiId == 33 || guiId == 34)
                {
                    char* jsonData = new char[jsonLength + 1];
                    bsData.Read(jsonData, jsonLength);
                    jsonData[jsonLength] = '\0';
                    CallOnJsonDataIncoming(guiId, jsonData);
                    delete[] jsonData;
                }
                else
                {
                    Packet_GUI(pkt);
                }
                break; 
            }
		}

		pRakClient->DeallocatePacket(pkt);
	}
}

int CNetGame::GetGameState()
{
	return *(int *)(CGameAPI::GetBase(xorstr("CNetGame::m_iGameState")));
}

void CNetGame::SetGameState(int state)
{
	*(int *)(CGameAPI::GetBase(xorstr("CNetGame::m_iGameState"))) = state;
}

#ifdef __arm__
void gen_auth_key(char buf[260], char* auth_in);
void CNetGame::Packet_AuthKey(Packet* pkt)
{
	RakNet::BitStream bsAuth((unsigned char *)pkt->data, pkt->length, false);

	uint8_t byteAuthLen;
	char szAuth[260];

	bsAuth.IgnoreBits(8);
	bsAuth.Read(byteAuthLen);
	bsAuth.Read(szAuth, byteAuthLen);
	szAuth[byteAuthLen] = '\0';

	char szAuthKey[260];
	gen_auth_key(szAuthKey, szAuth);

	RakNet::BitStream bsKey;
	uint8_t byteAuthKeyLen = (uint8_t)strlen(szAuthKey);

	bsKey.Write((uint8_t)ID_AUTH_KEY);
	bsKey.Write((uint8_t)byteAuthKeyLen);
	bsKey.Write(szAuthKey, byteAuthKeyLen);
	pRakClient->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, 0);
}
#endif

#ifdef __aarch64__
extern char AuthKeyTable[512][2][128];
void CNetGame::Packet_AuthKey(Packet* pkt)
{
    char* auth_key;
    bool found_key = false;

    for (int x = 0; x < 512; x++)
    {
        if (!strcmp(((char*)pkt->data + 2), AuthKeyTable[x][0]))
        {
            auth_key = AuthKeyTable[x][1];
            found_key = true;
        }
    }

    if (found_key)
    {
        RakNet::BitStream bsKey;
        BYTE byteAuthKeyLen;

        byteAuthKeyLen = (BYTE)strlen(auth_key);

        bsKey.Write((BYTE)ID_AUTH_KEY);
        bsKey.Write((BYTE)byteAuthKeyLen);
        bsKey.Write(auth_key, byteAuthKeyLen);

        pRakClient->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, NULL);

    }
    else
    {
    
    }
}
#endif

void CNetGame::Packet_ConnectionLost(Packet* pkt)
{
	reinterpret_cast<void(*)()>(CGameAPI::GetBase(xorstr("CNetGame::Packet_ConnectionLost")))();
	uintptr_t packetConnectionLostAddr = CGameAPI::GetBase(xorstr("CNetGame::Packet_ConnectionLost"));
	uintptr_t netGameAddr = CGameAPI::GetBase(xorstr("CNetGame::m_pRakClient"));
	if(!packetConnectionLostAddr || !netGameAddr) {
		return;
	}
	reinterpret_cast<void(*)(uintptr_t)>(packetConnectionLostAddr)(netGameAddr);
}

void CNetGame::Packet_ConnectionSucceeded(Packet* pkt)
{
	RakNet::BitStream bsSuccAuth((unsigned char *)pkt->data, pkt->length, false);
	uint16_t MyPlayerID;
	unsigned int uiChallenge;

	bsSuccAuth.IgnoreBits(8); // ID_CONNECTION_REQUEST_ACCEPTED
	bsSuccAuth.IgnoreBits(32); // binaryAddress
	bsSuccAuth.IgnoreBits(16); // port
	bsSuccAuth.Read(MyPlayerID);
	bsSuccAuth.Read(uiChallenge);

	CPlayerPool* pool = GetPlayerPool();
	if(!pool || !pool->GetLocalPlayer()) {
		return;
	}
	pool->GetLocalPlayer()->SetLocalPlayerID(MyPlayerID);

	int iVersion = NETGAME_VERSION;
	char byteMod = 0x01;
	unsigned int uiClientChallengeResponse = uiChallenge ^ iVersion;

	const char* sampVersion = xorstr("0.3.7");
	const char* auth_bs = xorstr("15121F6F18550C00AC4B4F8A167D0379BB0ACA99043");
	
	const char* localPlayerName = (const char *)(pool->GetLocalPlayer()->GetLocalPlayerName());
	
	char byteAuthBSLen = (char)strlen(auth_bs);
	char byteNameLen = (char)strlen(localPlayerName);
	char byteClientverLen = (char)strlen(sampVersion);

	RakNet::BitStream bsSend;
	bsSend.Write(iVersion);
	bsSend.Write(byteMod);
	bsSend.Write(byteNameLen);
	bsSend.Write(localPlayerName, byteNameLen);
	bsSend.Write(uiClientChallengeResponse);
	bsSend.Write(byteAuthBSLen);
	bsSend.Write(auth_bs, byteAuthBSLen);
	bsSend.Write(byteClientverLen);
	bsSend.Write(sampVersion, byteClientverLen);
	pRakClient->RPC(&RPC_ClientJoin, &bsSend, HIGH_PRIORITY, RELIABLE, 0, false, UNASSIGNED_NETWORK_ID, NULL);
	
	SetGameState(GAMESTATE_AWAIT_JOIN);
}

void CNetGame::Packet_AimSync(Packet* pkt)
{
    RakNet::BitStream bsData(pkt->data, pkt->length, false);
    
    if(GetGameState() != GAMESTATE_CONNECTED) { return; }
    
    uint16_t playerId = 0;
    uint8_t aimSyncBuffer[31] = {0};
    
    if(!ReadPacketPlayerHeader(pkt, bsData, ID_AIM_SYNC, playerId)) {
		return;
	}
    if(!bsData.ReadBits((unsigned char *)&aimSyncBuffer, 31 * 8)) {
		return;
	}
    
    CPlayerPool* pool = GetPlayerPool();
    if (!pool) { return; }
	CLocalPlayer* local_player = pool->GetLocalPlayer();
	if(local_player && local_player->GetLocalPlayerID() == playerId) {
		return;
	}
    CRemotePlayer* remote_player = pool->GetAt(playerId);
    if(remote_player) {
        remote_player->StoreAimSyncData(aimSyncBuffer, 0);
    }
}

void CNetGame::Packet_PlayerSync(Packet* pkt)
{
	RakNet::BitStream bsData(pkt->data, pkt->length, false);

	if(GetGameState() != GAMESTATE_CONNECTED) { return; }

	bool accepted_sync = false;

	uint8_t pktId = 0;
	uint16_t playerId = 0;
	uint32_t timestamp = 0;

	int16_t lrAnalog, udAnalog;
	uint16_t wKeys;
	CVector vecPos = {0.0f, 0.0f, 0.0f};
	float tw, tx, ty, tz;
	uint8_t byteHealthArmour = 0, byteHealth = 0, byteArmour = 0;
	CVector vecMoveSpeed = {0.0f, 0.0f, 0.0f};
	float mx, my, mz;
	uint16_t wSurfInfo = 0;
	CVector vecSurfOffsets = {0.0f, 0.0f, 0.0f};
	uint8_t byteCurrentWeapon = 0, byteSpecialAction = 0;

	if(pkt->data[0] == ID_TIMESTAMP) {
		bsData.ReadBits((unsigned char *)&pktId, 8);
		bsData.ReadBits((unsigned char *)&timestamp, 32);
	}
	bsData.ReadBits((unsigned char *)&pktId, 8);
	bsData.ReadBits((unsigned char *)&playerId, 16);

	int readOffset = bsData.readOffset;
	int numberOfBitsUsed = bsData.numberOfBitsUsed;
	if(readOffset >= numberOfBitsUsed) {
		return;
	}
	int v6 = bsData.data[readOffset >> 3];
	char v7 = readOffset & 7;
	int v8 = readOffset + 1;
	bsData.readOffset = v8;
	if (((v6 << v7) & 0x80) != 0)
	{
		if (!bsData.ReadBits((unsigned char *)&lrAnalog, 16))
		{
			return;
		}
		v8 = bsData.readOffset;
		numberOfBitsUsed = bsData.numberOfBitsUsed;
	} 
	else 
	{
		lrAnalog = 0;
	}
	if (v8 < numberOfBitsUsed)
	{
		int v9 = bsData.data[v8 >> 3];
		bsData.readOffset = v8 + 1;

		bool ok = true;

		if (((v9 << (v8 & 7)) & 0x80) != 0)
		{
			ok = bsData.ReadBits((unsigned char *)&udAnalog, 16);
		}
		else
		{
			udAnalog = 0;
		}

		if (ok
			&& bsData.ReadBits((unsigned char *)&wKeys, 16)
			&& bsData.Read((char *)&vecPos, 12)
			&& bsData.ReadNormQuat<float>(tw, tx, ty, tz)
			&& bsData.ReadBits((unsigned char *)&byteHealthArmour, 8)
			&& bsData.ReadBits((unsigned char *)&byteCurrentWeapon, 8)
			&& bsData.ReadBits((unsigned char *)&byteSpecialAction, 8)
			&& bsData.ReadVector<float>(mx, my, mz))
		{
			vecMoveSpeed = CVector(mx, my, mz);

			readOffset = bsData.readOffset;
			if (readOffset >= bsData.numberOfBitsUsed) {
				return;
			}
			int v7_ = bsData.data[readOffset >> 3];
			bsData.readOffset = readOffset + 1;
			if (((v7_ << (readOffset & 7)) & 0x80) != 0)
			{
				if (bsData.ReadBits((unsigned char *)&wSurfInfo, 16)
					&& bsData.ReadBits((unsigned char *)&vecSurfOffsets.x, 32)
					&& bsData.ReadBits((unsigned char *)&vecSurfOffsets.y, 32)
					&& bsData.ReadBits((unsigned char *)&vecSurfOffsets.z, 32))
				{
					// surf
				}
			}
			accepted_sync = true;
		}
	}

	uint8_t byteArmTemp = 0, byteHlTemp = 0;
	byteArmTemp = (byteHealthArmour & 0x0F);
	byteHlTemp = (byteHealthArmour >> 4);

	if(byteArmTemp == 0xF) {
	byteArmour = 100;
	} else if(byteArmTemp == 0) {
	byteArmour = 0;
	} else {
	byteArmour = byteArmTemp * 7;
	}

	if(byteHlTemp == 0xF) {
	byteHealth = 100;
	} else if(byteHlTemp == 0) {
	byteHealth = 0;
	} else {
	byteHealth = byteHlTemp * 7;
	}

	BROnFootSyncData ofSync = {0};
	ofSync.lrAnalogLeftStick = lrAnalog;
	ofSync.udAnalogLeftStick = udAnalog;
	ofSync.wKeys = wKeys;
	ofSync.vecPos = vecPos;
	ofSync.quatw = tw;
	ofSync.quatx = tx;
	ofSync.quaty = ty;
	ofSync.quatz = tz;
	ofSync.health = PackSampHealthArmourForBR(byteHealth);
	ofSync.armour = PackSampHealthArmourForBR(byteArmour);
	ofSync.byteCurrentWeapon = byteCurrentWeapon;
	ofSync.byteSpecialAction = byteSpecialAction;
	ofSync.vecMoveSpeed = vecMoveSpeed;
	ofSync.vecSurfOffsets = vecSurfOffsets;
	ofSync.wSurfInfo = wSurfInfo;

    CPlayerPool* pool = GetPlayerPool();
    if (!pool) { return; }
    CRemotePlayer* remote_player = pool->GetAt(playerId);
    if(remote_player && accepted_sync) {
        remote_player->StoreSyncData(&ofSync, 0);
    }
}
void CNetGame::Packet_VehicleSync(Packet* pkt)
{
	RakNet::BitStream bsData(pkt->data, pkt->length, false);
	
	if(GetGameState() != GAMESTATE_CONNECTED) { return; }
	
	uint16_t playerId = 0;
	
	BRInCarSyncData icsync = {0};
	
	if(!ReadPacketPlayerHeader(pkt, bsData, ID_VEHICLE_SYNC, playerId)) {
		return;
	}
	
	if(!bsData.ReadBits((unsigned char *)&icsync.VehicleID, 16)) { return; }
	if(!bsData.ReadBits((unsigned char *)&icsync.lrAnalogLeftStick, 16)) { return; }
	if(!bsData.ReadBits((unsigned char *)&icsync.udAnalogLeftStick, 16)) { return; }
	if(!bsData.ReadBits((unsigned char *)&icsync.wKeys, 16)) { return; }
	if(!bsData.ReadNormQuat<float>(icsync.quatw, icsync.quatx, icsync.quaty, icsync.quatz)) { return; }
	if(!bsData.ReadBits((unsigned char *)&icsync.vecPos, 96)) { return; }
	if(!bsData.ReadVector<float>(icsync.vecMoveSpeed.x, icsync.vecMoveSpeed.y, icsync.vecMoveSpeed.z)) { return; }
	uint16_t wTempCarHealth;
	if(!bsData.ReadBits((unsigned char *)&wTempCarHealth, 16)) { return; }
	icsync.fCarHealth = wTempCarHealth;
	
	uint8_t byteHealthArmour;
	uint8_t byteArmTemp = 0, byteHlTemp = 0;

	if(!bsData.Read(byteHealthArmour)) { return; }
	byteArmTemp = (byteHealthArmour & 0x0F);
	byteHlTemp = (byteHealthArmour >> 4);

	uint8_t playerArmour = 0;
	uint8_t playerHealth = 0;
	if(byteArmTemp == 0xF) {
		playerArmour = 100;
	} else if(byteArmTemp == 0) {
		playerArmour = 0;
	} else {
		playerArmour = byteArmTemp * 7;
	}
	
	if(byteHlTemp == 0xF) {
		playerHealth = 100;
	} else if(byteHlTemp == 0) {
		playerHealth = 0;
	} else {
		playerHealth = byteHlTemp * 7;
	}
	icsync.playerArmour = PackSampHealthArmourForBR(playerArmour);
	icsync.playerHealth = PackSampHealthArmourForBR(playerHealth);
	
	uint8_t byteTempWeapon;
	if(!bsData.Read(byteTempWeapon)) { return; }
	icsync.byteCurrentWeapon ^= (byteTempWeapon ^ icsync.byteCurrentWeapon) & 0x3F;
	
	bool bCheck;
	if(!bsData.ReadCompressed(bCheck)) { return; }
	if(bCheck) { icsync.byteSirenOn = 1; }
	if(!bsData.ReadCompressed(bCheck)) { return; }
	if(bCheck) { icsync.byteLandingGearState = 1; }
	if(!bsData.ReadCompressed(bCheck)) { return; }
	if(bCheck && !bsData.Read(icsync.TrailerID)) { return; }

    CPlayerPool* pool = GetPlayerPool();
    if (!pool) { return; }
    CRemotePlayer* remote_player = pool->GetAt(playerId);
    if(remote_player) {
        remote_player->StoreInCarSyncData(&icsync, 0);
    }
}

void CNetGame::Packet_PassengerSync(Packet* pkt)
{
	RakNet::BitStream bsData(pkt->data, pkt->length, false);
	
	if(GetGameState() != GAMESTATE_CONNECTED) { return; }
	
	uint16_t playerId = 0;
	uint8_t passengerSync[26] = {0};
	
	if(!ReadPacketPlayerHeader(pkt, bsData, ID_PASSENGER_SYNC, playerId)) {
		return;
	}
	if(!bsData.ReadBits((unsigned char *)&passengerSync, 26 * 8)) {
		return;
	}
	
    CPlayerPool* pool = GetPlayerPool();
    if (!pool) { return; }
    CRemotePlayer* remote_player = pool->GetAt(playerId);
    if(remote_player) {
        remote_player->StorePassengerSyncData(passengerSync, 0);
    }
}

void CNetGame::Packet_BulletSync(Packet* pkt)
{
	RakNet::BitStream bsData(pkt->data, pkt->length, false);
	
	if(GetGameState() != GAMESTATE_CONNECTED) { return; }
	
	uint16_t playerId = 0;
	uint8_t bulletSync[40] = {0};
	
	if(!ReadPacketPlayerHeader(pkt, bsData, ID_BULLET_SYNC, playerId)) {
		return;
	}
	if(!bsData.ReadBits((unsigned char *)&bulletSync, 40 * 8)) {
		return;
	}
	
    CPlayerPool* pool = GetPlayerPool();
    if (!pool) { return; }
    CRemotePlayer* remote_player = pool->GetAt(playerId);
    if(remote_player) {
        CLocalPlayer* local_player = pool->GetLocalPlayer();
        if(local_player && local_player->GetLocalPlayerID() != playerId) {
            remote_player->StoreBulletSyncData(bulletSync, 0);
        }
    }
}

void CNetGame::Packet_TurnLightsSync(Packet* pkt)
{
	uintptr_t packetTurnLightsSyncAddr = CGameAPI::GetBase(xorstr("CNetGame::Packet_TurnLightsSync"));
	if(!packetTurnLightsSyncAddr) {
		return;
	}
	reinterpret_cast<void(*)(Packet*)>(packetTurnLightsSyncAddr)(pkt);
}

void CNetGame::SendJsonData(int guiId, const char* data, uint32_t length)
{
    RakNet::BitStream bsSend;
    bsSend.Write((uint8_t)252);
    bsSend.Write((uint16_t)guiId);
    bsSend.Write((uint32_t)length);
    bsSend.Write(data, length);

    pRakClient->Send(&bsSend, SYSTEM_PRIORITY, RELIABLE_SEQUENCED, 0);
}

extern "C" JNIEXPORT void JNICALL Java_com_blackhub_bronline_game_core_JNIJSONTransport_sendJsonData(
    JNIEnv* env, jclass clazz, jint guiId, jbyteArray data)
{
    if (!data)
        return;

    jbyte* byteArray = env->GetByteArrayElements(data, nullptr);
    jsize length = env->GetArrayLength(data);

    if (guiId != 10)
        CNetGame::SendJsonData(guiId, (const char*)byteArray, (uint32_t)length);

    env->ReleaseByteArrayElements(data, byteArray, JNI_ABORT);
}


void CNetGame::Packet_GUI(Packet* pkt)
{
	uintptr_t packetGUIAddr = CGameAPI::GetBase(xorstr("CNetGame::Packet_GUI"));
	if(!packetGUIAddr) {
		return;
	}
    reinterpret_cast<void(*)(Packet*)>(packetGUIAddr)(pkt);
}
